import 'package:club/modals/product_modal.dart';
import 'package:club/modals/table_modal.dart';
import 'package:flutter/material.dart';


class ClubModal{
  final String id;
  final String name;
  final List<TableModal> tables;
  final List<ProductModal> products;


  // TODO: 
  // location
  // icon
  // reviews
  // rating

  ClubModal({
    this.id = '1',
    @required this.name,
    this.tables = const[],
    this.products = const [],
  });

  get totalNoTables => tables.length;

}