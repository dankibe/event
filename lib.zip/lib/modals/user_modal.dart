import 'package:flutter/material.dart';

class UserModal{
  final String id;
  final String username;

  // TODO:
  // conact
  // icon/profile

  UserModal({
    this.id = '1',
    @required this.username
  });
}